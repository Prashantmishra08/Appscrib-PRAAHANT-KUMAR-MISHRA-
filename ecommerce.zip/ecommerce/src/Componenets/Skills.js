

const Skills = () => {
  return (
    <h4>SKILLS</h4>
  )
}

export default Skills;