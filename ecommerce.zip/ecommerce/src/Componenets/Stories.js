

const Stories = () => {
  return (
    <h4>STORIES</h4>
  )
}

export default Stories