

const Contact = () => {
  return (
    <h4>CONTACT US</h4>
  )
}

export default Contact;