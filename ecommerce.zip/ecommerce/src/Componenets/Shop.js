

const Shop = () => {
  return (
    <h4>SHOP</h4>
  )
}

export default Shop;
