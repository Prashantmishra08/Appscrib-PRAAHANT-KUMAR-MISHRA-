

const About = () => {
  return (
    <h4>ABOUT</h4>
  )
}

export default About;